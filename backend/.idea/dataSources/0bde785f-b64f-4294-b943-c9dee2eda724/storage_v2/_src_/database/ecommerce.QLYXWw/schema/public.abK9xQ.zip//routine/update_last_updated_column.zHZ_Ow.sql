create function update_last_updated_column() returns trigger
    language plpgsql
as
$$ BEGIN NEW.last_updated = NOW(); RETURN NEW; END; $$;

alter function update_last_updated_column() owner to postgres;

